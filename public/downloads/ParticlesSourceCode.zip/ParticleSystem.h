#ifndef PARTICLESYSTEM_H
#define PARTICLESYSTEM_H

#include "GameObject.h"
#include "ParticleEmitter.h"
#include "TextFileIO.h"
#include <string.h>

class ParticleSystem : public GameObject
{
	private:
		//The name of this system
		char* name;
		//The name of the file that has the data this system needs
		char* particleSystemFileName;
		//a TextFileIO object used to get the data from the file
		TextFileIO particleSystemFile;
		//strings holding the emitter data
		char*** theEmittersData;
		//strings holding the time step data
		char*** theTimeStepData;
		//the number of emitters in this system
		int numEmitters;
		//An array of the emitter
		ParticleEmitter** theEmitters;
		//-------------------------------------------------------------------//
		// Function Prototype: void InitializeParticles(void)
		//
		// Purpose: Reads in all the data from the file and parses it
		//
		// Arguments: void
		//
		// Returns: void
		//
		// Calls To: atoi(), atof(), strlen(), strcat(), strtok(), getlineCount()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//			
		void GetAndParseFileData(void);
		//-------------------------------------------------------------------//
		// Function Prototype: void InitializeParticles(void)
		//
		// Purpose: Inits all the emitters in this system
		//
		// Arguments: void
		//
		// Returns: void
		//
		// Calls To: ParticleEmitter()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//	
		void InitializeEmitters(void);

	public:
		//-------------------------------------------------------------------//
		// Function Prototype: ParticleSystem(void)
		//
		// Purpose: This is the default constructor, it sets all member
		//		variables to 0 or NULL.
		//
		// Arguments: None
		//
		// Returns: n/a
		//
		// Calls To: None
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//
		ParticleSystem(void);
		//-------------------------------------------------------------------//
		// Function Prototype: ParticleSystem(char* fileName)
		//
		// Purpose: This is the typical constructor, it inits all the member data
		//
		// Arguments: char* fileName
		//
		// Returns: n/a
		//
		// Calls To: strncpy(), strlen(), GetAndParseFileData(), InitializeEmitters()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//
		ParticleSystem(char* fileName);
		//-------------------------------------------------------------------//
		// Function Prototype: Render(void)
		//
		// Purpose: This method renders all the Particle Emitters in this system
		//
		// Arguments: None
		//
		// Returns: n/a
		//
		// Calls To: ParticleEmitter::Render()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//
		void Render(void);
		void ToString(char** dataString);
};
ParticleSystem::ParticleSystem(void)
{
	name = NULL;
	theEmitters = NULL;
	theEmittersData = NULL;
	numEmitters = 0;
}
ParticleSystem::ParticleSystem(char* fileName)
{	
	//save the name of the file this system uses
	particleSystemFileName = new char[strlen(fileName) + 1];
	particleSystemFileName = strncpy(particleSystemFileName, fileName, strlen(fileName));
	particleSystemFileName[strlen(fileName)] = '\0';

	//get all the data from the file
	GetAndParseFileData();
	//give the parsed data to the Emitters
	InitializeEmitters();
}
void ParticleSystem::GetAndParseFileData(void)
{
	//holds all the file data
	char** allFileData;
	//the number of lines in the file
	int numLinesInFile = 0;
	//the number of timesteps in the fi;e
	int tempNumberOfTimeSteps = 0;
	//holds lines from the file
	char line[256] = {'\0'};
	//make a new TextFileIO object
	particleSystemFile = TextFileIO(particleSystemFileName);
	//get the number of lines in the file
	numLinesInFile = particleSystemFile.getLineCount();
	int fileLineCounter = 0;
	
	//get all the data in one fell swoop
	allFileData = new char*[numLinesInFile];
	for(int i = 0; i < numLinesInFile; i++)
	{
		//get each line from the file
		allFileData[i] = new char[1024];
		allFileData[i][0] = '\0';
		particleSystemFile.nextLine(allFileData[i]);
	}

	//save the name of the system
	name = new char[strlen(allFileData[0]) + 1];
	name = strncpy(name, allFileData[0], strlen(allFileData[0]));
	name[strlen(allFileData[0])] = '\0';
	
	//save the number of emitters
	numEmitters = atoi(allFileData[1]);

	//allocate memory for the Emitters data
	theEmittersData = new char**[numEmitters];
	//allocate memory for the time step data
	theTimeStepData = new char**[numEmitters];
	//move the line counter up 2
	fileLineCounter = 2;
		
		//for each emitter
		for(int j = 0; j < numEmitters; j++)
		{
			//make room for data
			theEmittersData[j] = new char*[8];
			theTimeStepData[j] = new char*[12];
			
			//get all the data for this emitter
			for(int k = 0; k < 8; k++)
			{
				//save each piece of the emitter data
				theEmittersData[j][k] = new char[1024];
				theEmittersData[j][k] = strncpy(theEmittersData[j][k], allFileData[fileLineCounter], strlen(allFileData[fileLineCounter]));
				theEmittersData[j][k][strlen(allFileData[fileLineCounter])] = '\0';
				fileLineCounter++;
			}
			//get the number of timesteps in this emitter
			tempNumberOfTimeSteps = atoi(allFileData[fileLineCounter]);
			theTimeStepData[j][0] = new char[1024];
			theTimeStepData[j][0] = strncpy(theTimeStepData[j][0], allFileData[fileLineCounter], strlen(allFileData[fileLineCounter]));
			theTimeStepData[j][0][strlen(allFileData[fileLineCounter])] = '\0';
			fileLineCounter++;
			//save all the timestep data
			for(int k = 1; k < 12; k++)
			{
				theTimeStepData[j][k] = new char[1024];
				theTimeStepData[j][k][0] = '\0'; 
			}
			for(int k = 0; k < tempNumberOfTimeSteps; k++)
			{
				
				//put all the data from the file into the format expected by the ParticleEmitter
				for(int l = 1; l < 12; l++)
				{
					strncat(theTimeStepData[j][l], allFileData[fileLineCounter], strlen(allFileData[fileLineCounter]));
					strncat(theTimeStepData[j][l], " ",1);
					fileLineCounter++;
				}
			}
			
		}
	
}
void ParticleSystem::InitializeEmitters(void)
{
	//make space for the emitters
	theEmitters = new ParticleEmitter*[numEmitters];
	//give the data saved from the file to the emitters
	for(int i = 0; i < numEmitters; i++)
	{	
		theEmitters[i] = new ParticleEmitter(theEmittersData[i], theTimeStepData[i]);
	}
}
void ParticleSystem::Render(void)
{

	bool liveEmitter = false;
	for(int i = 0; i < numEmitters; i++)
	{	
		//render each emitter
		if(theEmitters[i]->Render())
		{
			//this emitter is alive still
			liveEmitter = true; 
		}
	}
	//if there are no live emitters
	if(!liveEmitter)
	{
		//reset all the emitters
		for(int i = 0; i < numEmitters; i++)
		{	
			theEmitters[i]->Reset();
		}
	}
	
}

#endif
