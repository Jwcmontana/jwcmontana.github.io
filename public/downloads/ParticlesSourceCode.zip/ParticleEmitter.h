
#ifndef PARTICLEEMITTER_H
#define PARTICLEEMITTER_H

#include "Vector3d.h"
#include "ColorRGBA.h"
#include "GLTexture.h"
#include "Particle.h"
#include <string.h>

class ParticleEmitter
{
private:
	
	//The name of this emitter.
	char* name;
	//The velocity of this emitter, relative to it's system.
	Vector3d relativeVelocity;
	//The position of this emitter, relative to it's system.
	Vector3d relativePosition;
	//The position of this emitter, used to add velocity 
	//and not mess up the relativePosition member
	Vector3d tempPosition;
	//The string telling us if the Particles from this emitter
	//are squares or triangles. 
	char* particleType;
	//If the Particles from this emitter rotate
	bool particleRotation;
	//The texture for this emitters partilces.
	GLTexture particleTexture;
	//The maximum life time of a particle from this emitter.
	int particleLifeTimeHigh;
	//the minimum life time of a particle from this emitter.
	int particleLifeTimeLow;
	//how long this emitter continues to emit new particles.
	int lifetime;
	//the number of time steps this emitter has.
	int numTimeSteps;
	//An array holding the length of each time step.
	int* timeStepLengths;
	//The maximum velocity a particle from this system can have.
	Vector3d* velocityHigh;
	//The minimum velocity a particle from this system can have.
	Vector3d* velocityLow;
	//The maximum gravity a particle from this system can have.
	Vector3d* gravityHigh;
	//The minimum gravity a particle from this system can have.
	Vector3d* gravityLow;
	//The maximum color value a particle from this system can have.
	ColorRgba* colorHigh;
	//The minimum color value a particle from this system can have.
	ColorRgba* colorLow;
	//The maximum size value a particle from this system can have.
	float* sizeHigh;
	//The minimum size value a particle from this system can have.
	float* sizeLow;
	//The maximum numbmer of particle created in each frame of each time step.
	int* emissionRateHigh;
	//The minimum number of particle created in each frame of each time step.
	int* emissionRateLow;
	//The calculated number of particles to be emitted in each frame of the time step.
	int** emissionRates;
	//A three diamenisional array that holds pointers to each particle belonging to this 
	//emitter. The first diamension is the all the particles belonging to a time step, the 
	//second is all the particle belonging to a frame of that time step and the third are the pointers
	//to the particles themseleves.
	Particle**** theParticles;

	//used to count which time step we are on.
	int timeStepCounter;
	//used to count which frame within a time step we are on
	int frameCounter;


public:
	//-------------------------------------------------------------------//
	// Function Prototype: ParticleEmitter(void) 
	//
	// Purpose: This is the default constructor, it sets all member
	//		variables to 0 or NULL.
	//
	// Arguments: None
	//
	// Returns: n/a
	//
	// Calls To: None
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//
	ParticleEmitter(void);
	//-------------------------------------------------------------------//
	// Function Prototype: ParticleEmitter(char** particleEmitterData, char** timeStepData) 
	//
	// Purpose: This is the typical constructor, it calls a few member
	//		functions to initialize all the data members of the class.
	//
	// Arguments: char** particleEmitterData - A two dimenional array of
	//		strings, the the form of:
	//		
	//		particleEmitterData[0] = "Emitter One" 	char* name
	//		particleEmitterData[1] = "0 0 0"    	Vector3d relativeVelocity
	//		particleEmitterData[2] = "0 0 0"		Vector3d relativePosition
	//		particleEmitterData[3] = "Square"		char* particleType
	//		particleEmitterData[4] = "True"			bool particleRotation;
	//		particleEmitterData[5] = "texture.bmp"	GLTexture particleTexture
	//		particleEmitterData[6] = "100"			int particleLifeTimeHigh
	//		particleEmitterData[7] = "300"			int particleLifeTimeLow
	//
	//			   char** timeStepData - A two dimenional array of
	//		strings, the the form of:
	//
	//		timeStepData[0] = "2"							int numTimeSteps;
	//		timeStepData[1] = "25 25"						int* timeStepLengths;
	//		timeStepData[2] = "0 0 0 0 0 0"					Vector3d* velocityHigh;
	//		timeStepData[3] = "0 0 0 0 0 0"					Vector3d* velocityLow;
	//		timeStepData[4] = "0 0 0 0 0 0"					Vector3d* gravityHigh;
	//		timeStepData[5] = "0 0 0 0 0 0"					Vector3d* gravityLow;
	//		timeStepData[6] = ".8 .4 .2 .5 .8 .8 .4 .5"		ColorRgba* colorHigh;
	//		timeStepData[7] = ".5 .2 .5 .5 .6 .8 .5 .5"		ColorRgba* colorLow;
	//		timeStepData[8] = "100 200"						float* sizeHigh;
	//		timeStepData[9] = "50 50"						float* sizeLow;
	//		timeStepData[10] = "2 4 8 2"					int* emissionRateHigh;
	//		timeStepData[11] = "3 5 4 2"					int* emissionRateLow;
	//
	// Returns: n/a
	//
	// Calls To: ParseParticleEmitterData(particleEmitterData),
	//			 ParseTimeStepData(timeStepData),
	//			 InitializeParticles();
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//
	ParticleEmitter(char** particleEmitterData, char** timeStepData);

	//-------------------------------------------------------------------//
	// Function Prototype: void ParseParticleEmitterData(char** particleEmitterData) 
	//
	// Purpose: This method parse the particleEmitterData argument from the constructor
	//		and saves the data it parses in to the paritcle emitter attributes data members.
	//
	// Arguments: char** particleEmitterData - A two dimenional array of
	//		strings, the the form of:
	//		
	//		particleEmitterData[0] = "Emitter One" 	char* name
	//		particleEmitterData[1] = "0 0 0"    	Vector3d relativeVelocity
	//		particleEmitterData[2] = "0 0 0"		Vector3d relativePosition
	//		particleEmitterData[3] = "Square"		char* particleType
	//		particleEmitterData[4] = "True"			bool particleRotation;
	//		particleEmitterData[5] = "texture.bmp"	GLTexture particleTexture
	//		particleEmitterData[6] = "100"			int particleLifeTimeHigh
	//		particleEmitterData[7] = "300"			int particleLifeTimeLow
	//
	// Returns: void
	//
	// Calls To: strncpy(), strlen(), strtok(), atof(), atoi(), ParseVectorString()
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//
	void ParseParticleEmitterData(char** particleEmitterData);
	//-------------------------------------------------------------------//
	// Function Prototype: void ParseTimeStepData(char** timeStepData) 
	//
	// Purpose: This method parse the timeStepData argument from the constructor
	//		and saves the data it parses into the time step control data members.
	//
	// Arguments: char** timeStepData - A two dimenional array of
	//		strings, the the form of:
	//
	//		timeStepData[0] = "2"							int numTimeSteps;
	//		timeStepData[1] = "25 25"						int* timeStepLengths;
	//		timeStepData[2] = "0 0 0 0 0 0"					Vector3d* velocityHigh;
	//		timeStepData[3] = "0 0 0 0 0 0"					Vector3d* velocityLow;
	//		timeStepData[4] = "0 0 0 0 0 0"					Vector3d* gravityHigh;
	//		timeStepData[5] = "0 0 0 0 0 0"					Vector3d* gravityLow;
	//		timeStepData[6] = ".8 .4 .2 .5 .8 .8 .4 .5"		ColorRgba* colorHigh;
	//		timeStepData[7] = ".5 .2 .5 .5 .6 .8 .5 .5"		ColorRgba* colorLow;
	//		timeStepData[8] = "100 200"						float* sizeHigh;
	//		timeStepData[9] = "50 50"						float* sizeLow;
	//		timeStepData[10] = "2 4 8 2"					int* emissionRateHigh;
	//		timeStepData[11] = "3 5 4 2"					int* emissionRateLow;
	//
	//
	// Returns: void
	//
	// Calls To: strncpy(), strlen(), strtok(), atof(), atoi(), ParseVectorString(),
	//		ParseColorString()
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//
	void ParseTimeStepData(char** timeStepData);
	//-------------------------------------------------------------------//
	// Function Prototype: void InitializeParticles(void)
	//
	// Purpose: Using all the time step control attributes this function,
	//		chooses random values from the high and low ranges in the
	//		time step control attributes, for each particle in this emitter.
	//		This function then creates each Particle and store a pointer to 
	//		each one.
	//
	// Arguments: void
	//
	// Returns: void
	//
	// Calls To: ColorRgba::Random(), Vector3d::Random(), rand(), Particle()
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	void InitializeParticles(void);
	//-------------------------------------------------------------------//
	// Function Prototype: void Reset(void);
	//
	// Purpose: Resets all the Particle belonging to this emitter to new 
	// random values
	//
	// Arguments: void
	//
	// Returns: void
	//
	// Calls To: ColorRgba::Random(), Vector3d::Random(), rand(), Particle()
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	void Reset(void);
	//-------------------------------------------------------------------//
	// Function Prototype: void Render(void);
	//
	// Purpose: Renders all Particle belonging to this Emitter
	//
	// Arguments: void
	//
	// Returns: void
	//
	// Calls To: glGetFloatv(),	Vector3d(),	glDepthMask(), glDisable()
	//		glEnable(),	glBlendFunc(), GLTexture::Bind(), glMatrixMode()
	//  	glPushMatrix(), glTranslatef()
	//
	//
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	bool Render(void);
	//-------------------------------------------------------------------//
	// Function Prototype: 	Vector3d* ParseVectorString(Vector3d* storageArray, char* vectorData, int numSteps);
	//
	// Purpose: Parse a string full of vectors
	//
	// Arguments: Vector3d* storageArray - Where to put the parsed data
	//			  char* vectorData - The data to parse
	//			  int numSteps - The number of vectors to parse
	//
	// Returns: Vector3d* - An array of the parse vectors
	//
	// Calls To: strncpy(), strlen(), strtok(), atof(), Vector3d()
	//
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	Vector3d* ParseVectorString(Vector3d* storageArray, char* vectorData, int numSteps);
	//-------------------------------------------------------------------//
	// Function Prototype: ColorRgba* ParseColorString(ColorRgba* storageArray, char* colorData, int numSteps);
	//
	// Purpose: Parse a string full of color data
	//
	// Arguments: ColorRgba* storageArray - Where to put the parsed data
	//			  char* colorData - The data to parse
	//			  int numSteps - The number of colors to parse
	//
	// Returns: ColorRgba* - An Array of parsed colors
	//
	// Calls To: strncpy(), strlen(), strtok(), atof(), Vector3d()
	//
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	ColorRgba* ParseColorString(ColorRgba* storageArray, char* colorData, int numSteps);
	//-------------------------------------------------------------------//
	// Function Prototype: 	char** ToString(void);
	//
	// Purpose: Returns a char** that hold a string version of all the emitters data
	//
	// Arguments: void
	//
	// Returns: char** - An array of strings with all the emitter data
	//
	// Calls To: strncpy(), strlen(), strtok()
	//
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//	
	char** ToString(void);
	//-------------------------------------------------------------------//
	// Function Prototype: ~ParticleEmitter(void) 
	//
	// Purpose: This is the deconstructor, it sets deletes all memory allocated with new
	//
	// Arguments: None
	//
	// Returns: n/a
	//
	// Calls To: None
	//
	// Author: James W. Cramer
	//-------------------------------------------------------------------//
	~ParticleEmitter(void);	
	
};
//-------------------------------------------------------------------//
// Function Prototype: ParticleEmitter(void) 
//
// Purpose: This is the default constructor, it sets all member
//		variables to 0 or NULL.
//
// Arguments: None
//
// Returns: n/a
//
// Calls To: None
//
// Author: James W. Cramer
//-------------------------------------------------------------------//
ParticleEmitter::ParticleEmitter(void)
{
	
}
//-------------------------------------------------------------------//
// Function Prototype: ParticleEmitter(char** particleEmitterData, char** timeStepData) 
//
// Purpose: This is the typical constructor, it calls a few member
//		functions to initialize all the data members of the class.
//
// Arguments: char** particleEmitterData - A two dimenional array of
//		strings, the the form of:
//		
//		particleEmitterData[0] = "Emitter One" 	char* name
//		particleEmitterData[1] = "0 0 0"    	Vector3d relativeVelocity
//		particleEmitterData[2] = "0 0 0"		Vector3d relativePosition
//		particleEmitterData[3] = "Square"		char* particleType
//		particleEmitterData[4] = "True"			bool particleRotation;
//		particleEmitterData[5] = "texture.bmp"	GLTexture particleTexture
//		particleEmitterData[6] = "100"			int particleLifeTimeHigh
//		particleEmitterData[7] = "300"			int particleLifeTimeLow
//
//			   char** timeStepData - A two dimenional array of
//		strings, the the form of:
//
//		timeStepData[0] = "2"							int numTimeSteps;
//		timeStepData[1] = "25 25"						int* timeStepLengths;
//		timeStepData[2] = "0 0 0 0 0 0"					Vector3d* velocityHigh;
//		timeStepData[3] = "0 0 0 0 0 0"					Vector3d* velocityLow;
//		timeStepData[4] = "0 0 0 0 0 0"					Vector3d* gravityHigh;
//		timeStepData[5] = "0 0 0 0 0 0"					Vector3d* gravityLow;
//		timeStepData[6] = ".8 .4 .2 .5 .8 .8 .4 .5"		ColorRgba* colorHigh;
//		timeStepData[7] = ".5 .2 .5 .5 .6 .8 .5 .5"		ColorRgba* colorLow;
//		timeStepData[8] = "100 200"						float* sizeHigh;
//		timeStepData[9] = "50 50"						float* sizeLow;
//		timeStepData[10] = "2 4 8 2"					int* emissionRateHigh;
//		timeStepData[11] = "3 5 4 2"					int* emissionRateLow;
//
// Returns: n/a
//
// Calls To: ParseParticleEmitterData(particleEmitterData),
//			 ParseTimeStepData(timeStepData),
//			 InitializeParticles();
//
// Author: James W. Cramer
//-------------------------------------------------------------------//
ParticleEmitter::ParticleEmitter(char** particleEmitterData, char** timeStepData)
{
	timeStepCounter = 0;
	frameCounter = 0;

	//parse the particleEmitterData argument
	ParseParticleEmitterData(particleEmitterData);
	//parse the timeStepData argument
	ParseTimeStepData(timeStepData);
	//init the particles
	InitializeParticles();

}
//-------------------------------------------------------------------//
// Function Prototype: void ParticleEmitter::InitializeParticles(void)
//
// Purpose: The purpose of this method is to initialize the data member
//		theParticles. theParticles are dynamically allocated memory for 
//		a three dimensional of pointers to Particles. The first dimension
//		represents each TimeStep, the second is each frame of each TimeStep
//		amd the thrid dimension holds pointers to all the Particles belonging
//		to the frame. 
//
// Arguments: void
//
// Returns: void
//
// Calls To: ColorRgba::Random(), Vector3d::Random( ), rand( ),
//		Particle::Particle( )
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
void ParticleEmitter::InitializeParticles(void)
{
	//holds the random lifeTime for each particle
	int randomLifeTime;
	//This pointer is allocated an array of vectors, each
	//element of the array is then given a random value
	//between the high and low velocity values. This
	//array is then given to the Particle constructor.
	Vector3d* randomVelocityArray;
	//This pointer is allocated an array of vectors, each
	//element of the array is then given a random value
	//between the high and low gravity values.This
	//array is then given to the Particle constructor.
	Vector3d* randomGravityArray;
	//This pointer is allocated an array of color, each
	//element of the array is then given a random value
	//between the high and low color values.This
	//array is then given to the Particle constructor.
	ColorRgba* randomColorArray;
	//This pointer is allocated an array of floats, each
	//element of the array is then given a random value
	//between the high and low size values.This
	//array is then given to the Particle constructor.
	float* randomSizeArray;
	//holds a totally random rotation vector for each particle
	Vector3d randomRotation;
	//holds a totally random rotation angle for each particle
	float randomRotationAngle; 
	//used to generate random floats
	float randNum;
	
	//allocate just enough memory to hold velocity 
	//values for each time step
	randomVelocityArray = new Vector3d[numTimeSteps];
	//allocate just enough memory to hold gravity
	//values for each time step
	randomGravityArray = new Vector3d[numTimeSteps];
	//allocate just enough memory to hold color 
	//values for each time step
	randomColorArray = new ColorRgba[numTimeSteps];
	//allocate just enough memory to hold size 
	//values for each time step
	randomSizeArray = new float[numTimeSteps];

	//------------Allocate memory for theParticles array----------//
	//create the first dimension of theParticle array
	theParticles = new Particle***[numTimeSteps];
	
	//iterate through the first dimension of theParticles array
	for(int i = 0; i < numTimeSteps; i++)
	{
		//create a second dimension for each frame of each timeStep
		theParticles[i] = new Particle**[timeStepLengths[i]];

		//iterate through the second diamension 
		for(int j = 0; j < timeStepLengths[i]; j++)
		{
			//create the third diamesion, all particles belonging to a frame
			theParticles[i][j] = new Particle*[emissionRates[i][j]];
		}
	}
	//------------------------------------------------------------//

	//iterate through the first diamension of theParticles array
	for(int i = 0; i < numTimeSteps; i++)
	{
		//iterate through the second diamension of theParticles array
		for(int j = 0; j < timeStepLengths[i]; j++)
		{
			//iterate through the third diamension of theParticles array
			for(int k = 0; k < emissionRates[i][j]; k++)
			{
				//fill the random arrays we created above
				for(int l = 0; l < numTimeSteps; l++)
				{	
					//choose a random velocity for each timeStep, between the high
					//and low values
					randomVelocityArray[l].Random(velocityLow[l], velocityHigh[l]);
					//choose a random gravity for each timeStep, between the high
					//and low values
					randomGravityArray[l].Random(gravityLow[l], gravityHigh[l]);
					//choose a random color for each timeStep, between the high
					//and low values
					randomColorArray[l].Random(colorLow[l], colorHigh[l]);

					//get a random float
					randNum = (float)rand() / RAND_MAX;	
					//scale the random float from above to sit between the high and low values
					randomSizeArray[l] = sizeLow[l] + (sizeHigh[l] - sizeLow[l]) * randNum;	
				}
				
				//get a random number
				randNum = rand() / RAND_MAX;	
				//scale the random number between the high and low values
				randomLifeTime = particleLifeTimeLow + (particleLifeTimeHigh - particleLifeTimeLow) * randNum;

				//if Particles from this emitter rotate, calculate random
				//rotation vector and rotation angle 
				if(particleRotation)
				{
					//a total random rotation vector
					randomRotation.Random(Vector3d(-1,-1,-1), Vector3d(1,1,1));
					//get a random float
					randNum = (float)rand() / RAND_MAX;	
					//scale the float between 0 and 360
					randomRotationAngle = 0 + (360 - 0) * randNum;
				}
				//the Particles from this emitter don't rotate
				else
				{
					//no rotation 
					randomRotation = 0;
					randomRotationAngle = 0;
				}
				//allocate memory for a new Particle, give it the random values we calculated,
				//and save a pointer to the newly allocated memory
				theParticles[i][j][k] = new Particle(numTimeSteps,randomLifeTime, timeStepLengths, randomVelocityArray,
												randomGravityArray,randomColorArray,randomSizeArray,
												particleRotation, &randomRotation, randomRotationAngle);
			}

		}

	}
//clean up dynamically allocated memory 
//that we only needed for this function
delete[] randomVelocityArray;
delete[] randomGravityArray;
delete[] randomColorArray;
delete[] randomSizeArray;

}
void ParticleEmitter::Reset(void)
{
//holds the random lifeTime for each particle
	int randomLifeTime;
	//This pointer is allocated an array of vectors, each
	//element of the array is then given a random value
	//between the high and low velocity values. This
	//array is then given to the Particle constructor.
	Vector3d* randomVelocityArray;
	//This pointer is allocated an array of vectors, each
	//element of the array is then given a random value
	//between the high and low gravity values.This
	//array is then given to the Particle constructor.
	Vector3d* randomGravityArray;
	//This pointer is allocated an array of color, each
	//element of the array is then given a random value
	//between the high and low color values.This
	//array is then given to the Particle constructor.
	ColorRgba* randomColorArray;
	//This pointer is allocated an array of floats, each
	//element of the array is then given a random value
	//between the high and low size values.This
	//array is then given to the Particle constructor.
	float* randomSizeArray;
	//holds a totally random rotation vector for each particle
	Vector3d randomRotation;
	//holds a totally random rotation angle for each particle
	float randomRotationAngle; 
	//used to generate random floats
	float randNum;

	//allocate just enough memory to hold velocity 
	//values for each time step
	randomVelocityArray = new Vector3d[numTimeSteps];
	//allocate just enough memory to hold gravity
	//values for each time step
	randomGravityArray = new Vector3d[numTimeSteps];
	//allocate just enough memory to hold color 
	//values for each time step
	randomColorArray = new ColorRgba[numTimeSteps];
	//allocate just enough memory to hold size 
	//values for each time step
	randomSizeArray = new float[numTimeSteps];


	//iterate through the first diamension of theParticles array
	for(int i = 0; i < numTimeSteps; i++)
	{
		//iterate through the second diamension of theParticles array
		for(int j = 0; j < timeStepLengths[i]; j++)
		{
			//iterate through the third diamension of theParticles array
			for(int k = 0; k < emissionRates[i][j]; k++)
			{
				//fill the random arrays we created above
				for(int l = 0; l < numTimeSteps; l++)
				{	
					//choose a random velocity for each timeStep, between the high
					//and low values
					randomVelocityArray[l].Random(velocityLow[l], velocityHigh[l]);
					//choose a random gravity for each timeStep, between the high
					//and low values
					randomGravityArray[l].Random(gravityLow[l], gravityHigh[l]);
					//choose a random color for each timeStep, between the high
					//and low values
					randomColorArray[l].Random(colorLow[l], colorHigh[l]);

					//get a random float
					randNum = (float)rand() / RAND_MAX;	
					//scale the random float from above to sit between the high and low values
					randomSizeArray[l] = sizeLow[l] + (sizeHigh[l] - sizeLow[l]) * randNum;	
				}
				
				//get a random number
				randNum = rand() / RAND_MAX;	
				//scale the random number between the high and low values
				randomLifeTime = particleLifeTimeLow + (particleLifeTimeHigh - particleLifeTimeLow) * randNum;

				//if Particles from this emitter rotate, calculate random
				//rotation vector and rotation angle 
				if(particleRotation)
				{
					//a total random rotation vector
					randomRotation.Random(Vector3d(-1,-1,-1), Vector3d(1,1,1));
					//get a random float
					randNum = (float)rand() / RAND_MAX;	
					//scale the float between 0 and 360
					randomRotationAngle = 0 + (360 - 0) * randNum;
				}
				//the Particles from this emitter don't rotate
				else
				{
					//no rotation 
					randomRotation = 0;
					randomRotationAngle = 0;
				}
				//allocate memory for a new Particle, give it the random values we calculated,
				//and save a pointer to the newly allocated memory
				theParticles[i][j][k] = new Particle(numTimeSteps,randomLifeTime, timeStepLengths, randomVelocityArray,
												randomGravityArray,randomColorArray,randomSizeArray,
												particleRotation, &randomRotation, randomRotationAngle);
			}

		}

	}

	delete[] randomVelocityArray;
	delete[] randomGravityArray;
	delete[] randomColorArray;
	delete[] randomSizeArray;

}
//-------------------------------------------------------------------//
// Function Prototype: bool ParticleEmitter::Render(void)
//
// Purpose: This method renders all the Particle belonging to
//		this emitter. It also keeps track of which timeStep
//		and frame we are currently on so we only render the 
//		Particles for behind this frame of this timeStep
//
// Arguments: void
//
// Returns: bool - True if this emitter is still emitting Particles
//		or there is still a live particle belong to this emitter.
//				   False - This emitter has run it's course.
//
// Calls To: ColorRgba::glGetFloatv(), Vector3d(), 	glDepthMask(),		
//		glDisable( ), glEnable( ) glBlendFunc(GL_SRC_ALPHA,GL_DST_ALPHA),
//		GLTexture::Bind(), glMatrixMode( ), glPushMatrix( ), glPopMatrix( ),
//		glTranslatef( ), Particle::Update( ), Particle::Render( )
//		
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
bool ParticleEmitter::Render(void)
{
	 //holds the current model veiw matirx
	 float mat[16];
	 //used to test if a Particle belonging to this emitter is
	 //still alive
	 bool isLiveParticle = false;

	 //retrive the current model view matrix from opengl
	 glGetFloatv(GL_MODELVIEW_MATRIX, mat);
	 //save the up vector of the current frustrum,
	 //used to insure Particle always face the camera
	 Vector3d Up = Vector3d(mat[0], mat[4], mat[8]);
	 //save the right vector of the current frustrum,
	 //used to insure Particle always face the camera
	 Vector3d Right = Vector3d(mat[1], mat[5], mat[9]); 
  
	 //disable the depth mask because our Particles
	 //aren't depth sorted
	glDepthMask(GL_FALSE);
	//we don't need to do lighting eighter
	glDisable(GL_LIGHTING);
	//enable alpha blending
	glEnable(GL_BLEND);
	//set the alpha blending function
	glBlendFunc(GL_SRC_ALPHA,GL_DST_ALPHA);
	
	//bind the texture for this emitter
	particleTexture.Bind();
	
	//make sure we are dealing with the right matrix
	glMatrixMode(GL_MODELVIEW_MATRIX);
	//push a copy of the current model view matrix on to the stack
	glPushMatrix();
	//move to the position of this emitter
    glTranslatef(relativePosition.xyz[0],relativePosition.xyz[1],relativePosition.xyz[2]);
	
	//SPECIAL CASE: This is the first TimeStep
	if(timeStepCounter == 0)
	{
		//only use frames upto the current frame
		for(int i = 0; i < frameCounter; i++)
		{
			//for each particle in the current frame
			for(int j = 0; j < emissionRates[0][i]; j++)
			{
				//make sure the particle is still alive
				if(theParticles[0][i][j]->Update())
				{
					//the particle is alive
					isLiveParticle = true; 
					//render the particle
					theParticles[0][i][j]->Render(Right, Up);
				}
			}
		}
	}
	//SPECIAL CASE: We have used all the timeSteps,
	//but there are still particles that need to be rendered.
	//Render ALL the Particles belonging to this emitter. 
	else if(timeStepCounter > numTimeSteps)
	{
		//for each timeStep
		for(int i = 0; i < numTimeSteps; i++)
		{
			//for each frame of each timeStep
			for(int j = 0; j < timeStepLengths[i]; j++)
			{
				//for each particle of each frame
				for(int k = 0; k < emissionRates[i][j]; k++)
				{
					//update the Particle and make sure it's 
					//still alive
					if(theParticles[i][j][k]->Update())
					{
						//the particle is alive
						isLiveParticle = true; 
						//render the particle
						theParticles[i][j][k]->Render(Right, Up);
					}
				}
			}
		}
	}
	//General Case: This isn't the first timeStep
	else
	{
		//for each timeStep that has happened
		for(int i = 0; i <= timeStepCounter; i++)
		{
			//This is the timeStep we are currently on and it hasn't finished
			//all of it's frames
			if(timeStepCounter == i)
			{
				//for each frame of the current time step that 
				//has occured 
				for(int j = 0; j < frameCounter; j++)
				{
					//for each particle of each frame
					for(int k = 0; k < emissionRates[i][j]; k++)
					{
						//update the Particle and make sure it's still alive
						if(theParticles[i][j][k]->Update())
						{
							//the particle is alive
							isLiveParticle = true; 
							//render the particle
							theParticles[i][j][k]->Render(Right, Up);
						}
					}
				}
			}
			//we have completed this timeStep
			else
			{
				//for each frame of the time step
				for(int j = 0; j < timeStepLengths[i]; j++)
				{
					//for each Particle in the frame
					for(int k = 0; k < emissionRates[i][j]; k++)
					{
						//update the Particle and make sure it's still alive
						if(theParticles[i][j][k]->Update())
						{
							//the particle is alive
							isLiveParticle = true; 
							//render the particle
							theParticles[i][j][k]->Render(Right, Up);
						}
					}
				}
			}
		}
	}
	//increment the frame counter
	frameCounter++;

	//check if we have used all the frames of the current timeStep
	if(frameCounter > timeStepLengths[timeStepCounter])
	{
		//reset the frame counter 
		frameCounter = 0;
		//increment the timeStepCounter
		timeStepCounter++;
	}
	//add the velocity to the position 
	relativePosition += &relativeVelocity;	

	 //disable blending
	 glDisable(GL_BLEND);
	 //renable the depth mask
	 glDepthMask(GL_TRUE);
	 //renable lighting
	 glEnable(GL_LIGHTING);
	
	 //get rid of the martix we messed up
	 glPopMatrix();

	 //if we have been through all the timeSteps and
	 //there are not any Particles left alive
	 if(timeStepCounter > numTimeSteps && !isLiveParticle)
	 {
		//tell the caller of this method that this emitter has
		//run it's course
		return false;
	 }
	 //tell the caller that this emitter is still active	
	 return true;
}

void ParticleEmitter::ParseParticleEmitterData(char** particleEmitterData)
{
	char* copyVelocity; //holds a copy of the velocity element from the agrument string
	char* copyPosition; //holds a copy of the position element from the agrument string
	char* velocityComponets[3]; //holds velocity componets while we gather them 
	char* positionComponets[3]; //holds position componets while we gather them 
	float tempComponets[3]; //holds float versions of the above two char* 

	//--------------------Parse Particle Emitter Name-----------------------//
		name= new char[ strlen(particleEmitterData[0]) + 1];
		strncpy(name, particleEmitterData[0], strlen(particleEmitterData[0]));
		name[ strlen(particleEmitterData[0]) ] = '\0';
	//----------------------------------------------------------------------//
	
	
	//--------------------Parse Relative Velocity---------------------------//

		//Make a copy of the the argument string so we don't mess up the orignal
		copyVelocity = new char [strlen(particleEmitterData[1]) + 1];
		strncpy(copyVelocity,particleEmitterData[1],strlen(particleEmitterData[1]));
		copyVelocity[strlen(particleEmitterData[1])] = '\0';	

		//get the first token from the copy of the data string
		velocityComponets[0] = strtok(copyVelocity, " ");
		//get the rest of the tokens
		for(int i = 1; i < 3; i++)
		{
			//store the token
			velocityComponets[i] = strtok(NULL, " ");
		}
		//convert the stored tokens from strings to floats
		for(int i = 0; i < 3; i++)
		{
			tempComponets[i] = atof(velocityComponets[i]);
		}
		//initilize member variable with parsed data	
		relativeVelocity = Vector3d(tempComponets[0],tempComponets[1],tempComponets[2]);
		
	//----------------------------------------------------------------------//

	//--------------------Parse Relative Position---------------------------//

		//Make a copy of the the argument string so we don't mess up the orignal
		copyPosition = new char [strlen(particleEmitterData[2]) + 1];
		strncpy(copyPosition,particleEmitterData[2],strlen(particleEmitterData[2]));
		copyPosition[strlen(particleEmitterData[2])] = '\0';	

		//get the first token from the copy of the data string
		positionComponets[0] = strtok(copyPosition, " ");
		//get the rest of the tokens
		for(int i = 1; i < 3; i++)
		{
			//store the token
			positionComponets[i] = strtok(NULL, " ");
		}
		//convert the stored tokens from strings to floats
		for(int i = 0; i < 3; i++)
		{
			tempComponets[i] = atof(positionComponets[i]);
		}
		//initilize member variable with parsed data	
		relativePosition = Vector3d(tempComponets[0],tempComponets[1],tempComponets[2]);
		tempPosition  = relativePosition;
	//----------------------------------------------------------------------//
	
	//--------------------Parse Particle Type-------------------------------//
		particleType = new char [strlen(particleEmitterData[3]) + 1];
		strncpy(particleType, particleEmitterData[3], strlen(particleEmitterData[3]));
		particleType[ strlen(particleEmitterData[3]) ] = '\0';
	//----------------------------------------------------------------------//

	//--------------------Parse Particle Rotation-------------------------------//
		//see if the rotation is true
		if( strcmp(particleEmitterData[4], "True" ) == 0)
		{
			particleRotation = true;
		}
		//if it is not, save false
		else
		{
			particleRotation = false;
		}		
	//--------------------------------------------------------------------------//

	//--------------------Parse Particle Texture-------------------------------//
		particleTexture = GLTexture(particleEmitterData[5]);	
	//--------------------------------------------------------------------------//

	//--------------------Parse Particle LifeTime High--------------------------//
		particleLifeTimeHigh = atoi(particleEmitterData[6]);	
	//--------------------------------------------------------------------------//

	//--------------------Parse Particle LifeTime Low--------------------------//
		particleLifeTimeLow = atoi(particleEmitterData[7]);	
	//--------------------------------------------------------------------------//

	delete[] copyVelocity;
	delete[] copyPosition;
}
void ParticleEmitter::ParseTimeStepData(char** timeStepData)
{
	//These char*'s hold copys of data passed to the function
	//so that we don't mess up the string sent to us
	char* copyTimeStepLengthsData;
	char* copySizeHighData;
	char* copySizeLowData;
	char* copyEmissionRateHighData;
	char* copyEmissionRateLowData;

	//used to hold tokens
	char* token;

	//--------------------Parse Number Of TimeSteps----------------------------//
		numTimeSteps = atoi(timeStepData[0]);	
		
	//--------------------------------------------------------------------------//
	
	//--------------------Parse TimeSteps Lengths, Calc LifeTime----------------//
		lifetime = 0;
		timeStepLengths = new int[numTimeSteps];

		//Make a copy of the the argument string so we don't mess up the orignal
		copyTimeStepLengthsData = new char [strlen(timeStepData[1]) + 1];
		strncpy(copyTimeStepLengthsData,timeStepData[1],strlen(timeStepData[1]));
		copyTimeStepLengthsData[strlen(timeStepData[1])] = '\0';
		
		//get the first token from the copy of the data string
		token = strtok(copyTimeStepLengthsData, " ");
		//store the first token
		timeStepLengths[0] = atoi(token);
		lifetime += timeStepLengths[0];
		//get the rest of the tokens
		for(int i = 1; i < numTimeSteps; i++)
		{
			token = strtok(NULL, " ");
			timeStepLengths[i] = atoi(token);
			lifetime += timeStepLengths[i];
		}
	//--------------------------------------------------------------------------//

	//-Parse Velocity, Gravity, Color, High and Low Values via helper function--//

		velocityHigh = ParseVectorString(velocityHigh, timeStepData[2], numTimeSteps);
		velocityLow = ParseVectorString(velocityLow, timeStepData[3], numTimeSteps);
		gravityHigh = ParseVectorString(gravityHigh, timeStepData[4], numTimeSteps);
		gravityLow = ParseVectorString(gravityLow, timeStepData[5], numTimeSteps);

		colorHigh = ParseColorString(colorHigh, timeStepData[6], numTimeSteps);
		colorLow = ParseColorString(colorLow, timeStepData[7], numTimeSteps);

	//-------------------------------Parse Size High----------------------------//
		sizeHigh = new float[numTimeSteps];

		//Make a copy of the the argument string so we don't mess up the orignal
		copySizeHighData = new char [strlen(timeStepData[8]) + 1];
		strncpy(copySizeHighData,timeStepData[8],strlen(timeStepData[8]));
		copySizeHighData[strlen(timeStepData[8])] = '\0';
		
		//get the first token from the copy of the data string
		token = strtok(copySizeHighData, " ");
		//store the first token
		sizeHigh[0] = atof(token);
		//get the rest of the tokens
		for(int i = 1; i < numTimeSteps; i++)
		{
			token = strtok(NULL, " ");
			sizeHigh[i] = atof(token);
		}
	//--------------------------------------------------------------------------//
	//-------------------------------Parse Size Low----------------------------//
		sizeLow = new float[numTimeSteps];

		//Make a copy of the the argument string so we don't mess up the orignal
		copySizeLowData = new char [strlen(timeStepData[9]) + 1];
		strncpy(copySizeLowData,timeStepData[9],strlen(timeStepData[9]));
		copySizeLowData[strlen(timeStepData[9])] = '\0';
		
		//get the first token from the copy of the data string
		token = strtok(copySizeLowData, " ");
		//store the first token
		sizeLow[0] = atof(token);
		//get the rest of the tokens
		for(int i = 1; i < numTimeSteps; i++)
		{
			token = strtok(NULL, " ");
			sizeLow[i] = atof(token);
		}
	//--------------------------------------------------------------------------//

	//-------------------------------Parse Emission Rate High----------------------------//
		emissionRateHigh = new int[numTimeSteps];

		//Make a copy of the the argument string so we don't mess up the orignal
		copyEmissionRateHighData = new char [strlen(timeStepData[10]) + 1];
		strncpy(copyEmissionRateHighData,timeStepData[10],strlen(timeStepData[10]));
		copyEmissionRateHighData[strlen(timeStepData[10])] = '\0';
		
		//get the first token from the copy of the data string
		token = strtok(copyEmissionRateHighData, " ");
		//store the first token
		emissionRateHigh[0] = atoi(token);
		//get the rest of the tokens
		for(int i = 1; i < numTimeSteps; i++)
		{
			token = strtok(NULL, " ");
			emissionRateHigh[i] = atoi(token);
		}
	//--------------------------------------------------------------------------//
	//-------------------------------Parse Emission Rate Low----------------------------//
		emissionRateLow = new int[numTimeSteps];

		//Make a copy of the the argument string so we don't mess up the orignal
		copyEmissionRateLowData = new char [strlen(timeStepData[11]) + 1];
		strncpy(copyEmissionRateLowData,timeStepData[11],strlen(timeStepData[11]));
		copyEmissionRateLowData[strlen(timeStepData[11])] = '\0';
		
		//get the first token from the copy of the data string
		token = strtok(copyEmissionRateLowData, " ");
		//store the first token
		emissionRateLow[0] = atoi(token);
		//get the rest of the tokens
		for(int i = 1; i < numTimeSteps; i++)
		{
			token = strtok(NULL, " ");
			emissionRateLow[i] = atoi(token);
		}
	//--------------------------------------------------------------------------//
	
	//---------Calculate Emission Rate For Each Frame And Store Them------------//	
	emissionRates = new int*[numTimeSteps];
	
	for(int i = 0; i < numTimeSteps; i++)
	{
		emissionRates[i] = new int[timeStepLengths[i]];
	}
	for(int i = 0; i < numTimeSteps; i++)
	{
		for(int j = 0; j < timeStepLengths[i]; j++)
		{
			if(emissionRateHigh[i] >= emissionRateLow[i])
			{
				emissionRates[i][j] = (emissionRateLow[i] + rand( ) % (emissionRateHigh[i] - emissionRateLow[i] + 1) );
			}
			else
			{
				emissionRates[i][j] = (emissionRateHigh[i] + rand( ) % (emissionRateLow[i] - emissionRateHigh[i] + 1) );

			}
		}
	}
	//--------------------------------------------------------------------------//
	
	//clean up the memory for other programs and myself
	delete[] copyTimeStepLengthsData;
	delete[] copySizeHighData;
	delete[] copySizeLowData;
	delete[] copyEmissionRateHighData;
	delete[] copyEmissionRateLowData;

}
Vector3d* ParticleEmitter::ParseVectorString(Vector3d* storageArray, char* vectorData, int numSteps)
{
	//used for tokenizing
	char* token;
	//holds a copy of the argument string
	//so that we don't mess up the orignal
	char* vectorDataCopy;
	//holds the vector componets while we gather them
	float tempComponets[3];

	//allocate memory to store the vector data
	//and store the pointer in the argument so the
	//caller has access to the memory when this function returns
	storageArray = new Vector3d[numSteps];

	//Make a copy of the the argument string so we don't mess up the orignal
	vectorDataCopy = new char [strlen(vectorData) + 1];
	strncpy(vectorDataCopy,vectorData,strlen(vectorData));
	vectorDataCopy[strlen(vectorData)] = '\0';
	
	//for each time step tokenize and save componets to form a vector
	for(int i = 0; i < numSteps; i++)
	{
		//if this is the first pass
		if(i == 0)
		{
			//start the tokenizer and save the first token
			token = strtok(vectorDataCopy, " ");
			tempComponets[0] = atof(token);
			//get the other two tokens and convert and save them
			for(int j = 1; j < 3; j++)
			{
				token = strtok(NULL, " ");
				tempComponets[j] = atof(token);
			}
		}
		//this is the second or subsequent pass
		else
		{
			//get all the tokens for this vector, convert and save them
			for(int k = 0; k < 3; k++)
			{
				token = strtok(NULL, " ");
				tempComponets[k] = atof(token);
			}
		}

		//create the vector for this time step
		storageArray[i] = Vector3d(tempComponets[0],
								   tempComponets[1],
								   tempComponets[2]);
	}
	delete[] vectorDataCopy;
	return storageArray;
}
ColorRgba* ParticleEmitter::ParseColorString(ColorRgba* storageArray, char* colorData, int numSteps)
{
	//used for tokenizing
	char* token;
	//holds a copy of the argument string
	char* colorDataCopy;
	//holds the color componets while we gather all the componets
	float tempColorComponets[4];
	//allocate the requested memory 
	storageArray = new ColorRgba[numSteps];

	//Make a copy of the the argument string so we don't mess up the orignal
	colorDataCopy = new char [strlen(colorData) + 1];
	strncpy(colorDataCopy,colorData,strlen(colorData));
	colorDataCopy[strlen(colorData)] = '\0';
	
	//for each time step get the componets to form a color
	//from the argument string
	for(int i = 0; i < numSteps; i++)
	{
		//if this is the first pass
		if(i == 0)
		{
			//start the tokenizer
			token = strtok(colorDataCopy, " ");
			//get the first componet
			tempColorComponets[0] = atof(token);
			//get the other 3 componets 
			for(int j = 1; j < 4; j++)
			{
				token = strtok(NULL, " ");
				//convert and store the componet
				tempColorComponets[j] = atof(token);
			}
		}
		//this is not the first pass
		else
		{
			//get and store the componets
			for(int k = 0; k < 4; k++)
			{
				token = strtok(NULL, " ");
				tempColorComponets[k] = atof(token);
			}
		}

		//initialze the current element with the gathered data
		storageArray[i] = ColorRgba(tempColorComponets[0],
								    tempColorComponets[1],
								    tempColorComponets[2],
								    tempColorComponets[3]);
	}
	delete[] colorDataCopy;
	return storageArray;
}
char** ParticleEmitter::ToString(void)
{
	char** dataString;
	dataString = new char*[21];
	char *buffer;
	char *conversionBuffer;
	int index = 0;
	buffer = new char[20000];
	conversionBuffer = new char[33]; 
	buffer[0] = '\0';
	conversionBuffer[0] = '\0';

	dataString[0] = new char[strlen(name) + 1];
	strncpy(dataString[0], name, strlen(name));
	dataString[0][strlen(name)] = '\0';

	dataString [1] = new char[strlen(relativeVelocity.ToString()) + 1];
	strncpy(dataString[1], relativeVelocity.ToString(), strlen(relativeVelocity.ToString()));
	dataString[1][strlen(relativeVelocity.ToString())] = '\0';
	
	dataString [2] = new char[strlen(relativePosition.ToString()) + 1];
	strncpy(dataString[2], relativePosition.ToString(), strlen(relativePosition.ToString()));
	dataString[2][strlen(relativePosition.ToString())] = '\0';
	
	dataString[3] = new char[strlen(particleType) + 1];
	strncpy(dataString[3], particleType, strlen(particleType));
	dataString[3][strlen(particleType)] = '\0';

	
	
	if(particleRotation)
	{
		dataString[4] = new char[strlen("True\0")];
		strcpy(dataString[4], "True\0");
	}
	else
	{
		dataString[4] = new char[strlen("False\0")];
		strcpy(dataString[4], "False\0");
	}
	dataString[5] = new char[strlen(particleTexture.getFileName()) + 1];
	strncpy(dataString[5], particleTexture.getFileName(), strlen(particleTexture.getFileName()));
	dataString[5][strlen(particleTexture.getFileName())] = '\0';

	
	dataString[6] = new char[33];
	dataString[7] = new char[33];
	dataString[8] = new char[33];
	dataString[9] = new char[33];
	dataString[6] = itoa(particleLifeTimeHigh, dataString[6], 10);
	dataString[7] = itoa(particleLifeTimeLow, dataString[7], 10);
	dataString[8] = itoa(lifetime, dataString[8], 10);
	dataString[9] = itoa(numTimeSteps, dataString[9], 10);
	//end emitter data=------------------------------------------------------//
	
	dataString[10] = new char[1024];
	int counter = 0;
	for(int i = 0; i < numTimeSteps; i++)
	{	
		conversionBuffer = itoa(timeStepLengths[i],conversionBuffer,10);
		strncat(buffer,conversionBuffer, strlen(itoa(timeStepLengths[i],conversionBuffer,10)));
		strncat(buffer, " ", 1);
		conversionBuffer[0] = '\0';
	}
	strcpy(dataString[10],buffer);
	buffer[0] = '\0';
	

	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, velocityHigh[i].ToString());
	}
	dataString[11] = new char[strlen(buffer) + 1];
	strcpy(dataString[11], buffer);
	dataString[11][strlen(buffer)] = '\0';
	buffer[0] = '\0';
	
	
	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, velocityLow[i].ToString());
	}
	dataString[12] = new char[strlen(buffer) + 1];
	strcpy(dataString[12], buffer);
	dataString[12][strlen(buffer)] = '\0';
	buffer[0] = '\0';
	
	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, gravityHigh[i].ToString());
	}
	dataString[13] = new char[strlen(buffer) + 1];
	strcpy(dataString[13], buffer);
	dataString[13][strlen(buffer)] = '\0';
	buffer[0] = '\0';

	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, gravityLow[i].ToString());
	}
	dataString[14] = new char[strlen(buffer) + 1];
	strcpy(dataString[14], buffer);
	dataString[14][strlen(buffer)] = '\0';
	buffer[0] = '\0';
	
	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, colorHigh[i].ToString());
	}
	dataString[15] = new char[strlen(buffer) + 1];
	strcpy(dataString[15], buffer);
	dataString[15][strlen(buffer)] = '\0';
	buffer[0] = '\0';

	for(int i = 0; i < numTimeSteps; i++)
	{
		strcat(buffer, colorLow[i].ToString());
	}
	dataString[16] = new char[strlen(buffer) + 1];
	strcpy(dataString[16], buffer);
	dataString[16][strlen(buffer)] = '\0';
	buffer[0] = '\0';

	index = 0;
	for(int i = 0; i < numTimeSteps; i++)
	{
		index += sprintf( conversionBuffer, " %f ",sizeHigh[i]);
		strcat(buffer, conversionBuffer);
		conversionBuffer[0] = '\0';
	}
	buffer[index] = '\0';
	dataString[17] = new char[strlen(buffer) + 1];
	strcpy(dataString[17], buffer);
	buffer[0] = '\0';;
	
	index = 0;
	for(int i = 0; i < numTimeSteps; i++)
	{
		index += sprintf( conversionBuffer, " %f ",sizeLow[i]);
		strcat(buffer, conversionBuffer);
		conversionBuffer[0] = '\0';
	}
	buffer[index] = '\0';
	dataString[18] = new char[strlen(buffer) + 1];
	strcpy(dataString[18], buffer);
	buffer[0] = '\0';

	for(int i = 0; i < numTimeSteps; i++)
	{	
		conversionBuffer = itoa(emissionRateHigh[i],conversionBuffer,10);
		strncat(buffer,conversionBuffer, strlen(itoa(emissionRateHigh[i],conversionBuffer,10)));
		strncat(buffer, " ", 1);
		conversionBuffer[0] = '\0';
	}
	dataString[19] = new char[strlen(buffer) + 1];
	strncpy(dataString[19],buffer,strlen(buffer));
	dataString[19][strlen(buffer)] = '\0';
	buffer[0] = '\0';

	for(int i = 0; i < numTimeSteps; i++)
	{	
		conversionBuffer = itoa(emissionRateLow[i],conversionBuffer,10);
		strncat(buffer,conversionBuffer, strlen(itoa(emissionRateLow[i],conversionBuffer,10)));
		strncat(buffer, " ", 1);
		conversionBuffer[0] = '\0';
	}

	dataString[20] = new char[strlen(buffer) + 1];
	strncpy(dataString[20],buffer,strlen(buffer));
	dataString[20][strlen(buffer)] = '\0';
	buffer[0] = '\0';
	return dataString;
	
}

ParticleEmitter::~ParticleEmitter(void)
{
	

	delete[] name;
	delete[] particleType;
	delete[] timeStepLengths;
	
	delete[] velocityHigh;
	delete[] velocityLow;
	delete[] gravityHigh;
	delete[] gravityLow;
	delete[] colorHigh;
	delete[] colorLow;
	delete[] sizeHigh;
	delete[] sizeLow;
	delete[] emissionRateHigh;
	delete[] emissionRateLow;

	
}

#endif
