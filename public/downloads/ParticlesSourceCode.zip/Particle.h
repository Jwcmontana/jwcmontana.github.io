#ifndef PARTICLE_H
#define PARTICLE_H

#include "Vector3d.h"
#include "ColorRGBA.h"

class Particle
{
	private:

		//The current position Of This Particle Relative To It's Emitter
		Vector3d position;
		//The current velocity of the particle
		Vector3d velocity;
		//The amount of velocity added to the Particle each Update(),
		//for each differnet Time Step
		Vector3d* velocityStep;
		//The current amount of "gravity" subtracted from the Particle's velocity
		Vector3d gravity;
		//The amount of "gravity" added each Update(),
		//for each differnet Time Step
		Vector3d* gravityStep;
		//The current color of the Particle 
		ColorRgba color;
		//The value added to the current color each Update(),
		//for each differnet Time Step
		ColorRgba* colorStep;
		//The current size of the Particle
		float size;
		//The value added to the current size each Update(),
		//for each differnet Time Step
		float* sizeStep;
		//If this variable is true the Particle Rotates 
		bool rotating;
		//The vector that the Particle rotates Around
		Vector3d rotation;
		//The Angle the Particle rotates around the above vector
		float rotationAngle;
		//The number of frames this particle is on the screen
		int lifeTime;
		//The number of Time Steps this Particle has
		int numberOfTimeSteps;
		//An array that holds the length of each Time Step
		int*timeStepLengths;
		//Used To Calculate The Four Cornors Of The Particle
		Vector3d geometery[4];
		//Used to keep track of which Time Step this Particle is on
		int timeStepCounter;

	public:
		//-------------------------------------------------------------------//
		// Function Prototype: Particle::Particle(void) 
		//
		// Purpose: This is the default constructor, it sets all member
		//		variables to 0 or NULL.
		//
		// Arguments: None
		//
		// Returns: n/a
		//
		// Calls To: None
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//
		Particle(void);
		//-------------------------------------------------------------------//
		// Function Prototype: Particle::Particle(int numTimesSteps, 
		//										  int lifeTimeArg,
		//										  int *timeStepLengthArgArray, 
		//										  Vector3d* velocityArgArray,
		//										  Vector3d* gravityArgArray,
		//									      ColorRgba* colorArgArray, 
		//										  float* sizeArgArray,
		//										  bool rotatingArg, 
		//										  Vector3d* rotationArg, 
		//										  float rotationAngleArg)
		//
		// Purpose: This method initializes all of the member variables.
		//		Using the arguments, it calculates or stores the needed
		//		values. Since the algorithm used to calculate the values
		//		is complicated, see the method code for futher information
		//
		// Arguments: int numTimesSteps - The number of Time Steps to give
		//				to this Particle.
		//			  
		//			  int lifeTimeArg - The lifetime of this Particle.
		//			 
		//			  int *timeStepLengthArgArray - A pointer to an 
		//				array with each element representing the length 
		//				of each Time Step.
		//			  
		//			  Vector3d* velocityArgArray - A pointer to an
		//				array with each element representing the
		//				velocity for each Time Step.
		//			  
		//			  Vector3d* gravityArgArray - A pointer to an
		//				array with each element representing the
		//				gravity for each Time Step.
		// 
		//			  ColorRgba* colorArgArray - A pointer to an
		//				array with each element representing the
		//				color for each Time Step. 
		//
		//			  float* sizeArgArray - A pointer to an
		//				array with each element representing the
		//				size for each Time Step.
		//
		//			  bool rotatingArg - If this Particle rotates.
		//
		//			  Vector3d* rotationArg - The vector to rotate
		//				the Particle around.
		//
		//			  float rotationAngleArg - The angle to rotate
		//				around the rotation vector.
		//
		// Returns: n/a
		//
		// Calls To: None
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//		
		Particle(int numTimesSteps, int lifeTimeArg, int *timeStepLengthArgArray, Vector3d* velocityArgArray,
				 Vector3d* gravityArgArray, ColorRgba* colorArgArray, float* sizeArgArray,
				 bool rotatingArg, Vector3d* rotationArg, float rotationAngleArg);
		//-------------------------------------------------------------------//
		// Function Prototype: bool Particle::Update(void) 
		//
		// Purpose: This methods adds the velocityStep, the gravityStep,
		//			the colorStep and the sizeStep to the current velocity,
		//			gravity, color and size, respectivly. The array element 
		//			chosen from each step is determined by which Time Step
		//			this Particle is currently on. The velocity and gravity
		//			are then added and subtracted, respectivly from the Particles
		//			position.
		//
		// Arguments: None
		//
		// Returns: bool - True if the Particle is still alive, false if 
		//				the Particle is dead and it's lifetime over.
		//
		// Calls To: None
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//		
		bool Update(void);
		//-------------------------------------------------------------------//
		// Function Prototype: void Particle::Render(Vector3d Right, Vector3d Up)
		//
		// Purpose: This method is responsiable for actually, translating, 
		//			rotationing (if necessary) and drawing the Particle
		//			using it's current position, color and size.
		//
		// Arguments: Vector3d Right - The vector specifies the right
		//					side of the view frustum.
		//			  Vector3d Up - The vector specifies the up
		//					side of the view frustum.
		//
		// Returns: void
		//
		// Calls To: glMatrixMode(), glPushMatrix(), glTranslatef()
		//		     glRotatef(), glColor4fv(), glBegin(), glTexCoord2d()
        //			 glVertex3fv(),	glTexCoord2d(), glVertex3fv(),
		//			 glTexCoord2d(), glVertex3fv(), glTexCoord2d(), 
		//			 glVertex3fv(), glEnd(), glPopMatrix()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//	
		void Render(Vector3d Right, Vector3d Up);
		//-------------------------------------------------------------------//
		// Function Prototype: char** Particle::ToString(void)
		//
		// Purpose: This method is converts all the data members to strings,
		//			and then orginizes the strings into a two diamentional array.
		//
		// Arguments: void
		//
		// Returns: char** - A two diamension array of strings representing
		//				the values of all the data members
		//
		// Calls To: Vector3d::ToString(), ColorRgba::ToString(), strncpy()
		//			 strlen(), sprintf(), itoa()
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//	
		char** ToString(void);
		//-------------------------------------------------------------------//
		// Function Prototype: Particle::~Particle(void)
		//
		// Purpose: This is the deconstructor, it deletes all dynamically 
		//			allocated memory used by this Particle.
		//
		// Arguments: void
		//
		// Returns: (n/a)
		//
		// Calls To: none
		//
		// Author: James W. Cramer
		//-------------------------------------------------------------------//	
		~Particle(void);
};

//-------------------------------------------------------------------//
// Function Prototype: Particle::Particle(void) 
//
// Purpose: This is the default constructor, it sets all member
//		variables to 0 or NULL.
//
// Arguments: None
//
// Returns: n/a
//
// Calls To: None
//
// Author: James W. Cramer
//-------------------------------------------------------------------//
Particle::Particle(void)
{
	//set each element of geometery array to 0
	for(int i = 0; i < 4; i++)
	{
		geometery[i] = 0;
	}
	//set the position to 0
	position = 0;
	//set the velocity to 0
	velocity = 0;
	//set the velocityStep pointer to NULL
	velocityStep = NULL;
	//set the gravity to 0
	gravity = 0;
	//set the gravityStep pointer to NULL
	gravityStep = NULL;
	//set the color to 0
	color = 0;
	//set the colorStep pointer to NULL
	colorStep = NULL;
	//set the size to 0
	size = 0;
	//set the sizeStep pointer to NULL
	sizeStep = NULL;
	//set rotation to false
	rotating = false;
	//set the rotation vector to 0
	rotation = 0;
	//set the rotation angle to 0
	rotationAngle = 0;
	//set the lifetime to 0
	lifeTime = 0;
	//set the time step counter to 0
	timeStepCounter = 0;
	//set the timeStepLengths pointer to NULL
	timeStepLengths = NULL;;
}

//-------------------------------------------------------------------//
// Function Prototype: Particle::Particle(int numTimesSteps, 
//										  int lifeTimeArg,
//										  int *timeStepLengthArgArray, 
//										  Vector3d* velocityArgArray,
//										  Vector3d* gravityArgArray,
//									      ColorRgba* colorArgArray, 
//										  float* sizeArgArray,
//										  bool rotatingArg, 
//										  Vector3d* rotationArg, 
//										  float rotationAngleArg)
//
// Purpose: This method initializes all of the member variables.
//		Using the arguments, it calculates or stores the needed
//		values. Since the algorithm used to calculate the values
//		is complicated, see the method code for futher information
//
// Arguments: int numTimesSteps - The number of Time Steps to give
//				to this Particle.
//			  
//			  int lifeTimeArg - The lifetime of this Particle.
//			 
//			  int *timeStepLengthArgArray - A pointer to an 
//				array with each element representing the length 
//				of each Time Step.
//			  
//			  Vector3d* velocityArgArray - A pointer to an
//				array with each element representing the
//				velocity for each Time Step.
//			  
//			  Vector3d* gravityArgArray - A pointer to an
//				array with each element representing the
//				gravity for each Time Step.
// 
//			  ColorRgba* colorArgArray - A pointer to an
//				array with each element representing the
//				color for each Time Step. 
//
//			  float* sizeArgArray - A pointer to an
//				array with each element representing the
//				size for each Time Step.
//
//			  bool rotatingArg - If this Particle rotates.
//
//			  Vector3d* rotationArg - The vector to rotate
//				the Particle around.
//
//			  float rotationAngleArg - The angle to rotate
//				around the rotation vector.
//
// Returns: n/a
//
// Calls To: None
//
// Author: James W. Cramer
//-------------------------------------------------------------------//		
Particle::Particle(int numTimeSteps, int lifeTimeArg, int *timeStepLengthArgArray, Vector3d* velocityArgArray,
				   Vector3d* gravityArgArray, ColorRgba* colorArgArray, float* sizeArgArray,
				   bool rotatingArg, Vector3d* rotationArg, float rotationAngleArg)
{
	
	//The ratio of the lifeTime of this Particle
	//to the length of all this Particles Time Step
	float timeStepToLifeTimeRatio = 0;
	//the length of the Time Step we are currently working on
	int currentTimeLength = 0;
	//Make sure our timeStepCounter is 0
	timeStepCounter = 0;
	//Create the space for the velocity step for each Time Step
	//We subtract 1 becuase the first Time Step is the
	//Particles starting values. 
	velocityStep = new Vector3d[numTimeSteps - 1];
	//Create the space for the gravity step for each Time Step
	//We subtract 1 becuase the first Time Step is the
	//Particles starting values. 	
	gravityStep = new Vector3d[numTimeSteps - 1];
	//Create the space for the color step for each Time Step
	//We subtract 1 becuase the first Time Step is the
	//Particles starting values. 	
	colorStep = new ColorRgba[numTimeSteps - 1];
	//Create the space for the size step for each Time Step
	//We subtract 1 becuase the first Time Step is the
	//Particles starting values. 
	sizeStep = new float[numTimeSteps - 1];
	//Create the space for the lenght of each Time Step
	//We subtract 1 becuase the first Time Step is the
	//Particles starting values. 
	timeStepLengths = new int[numTimeSteps - 1];
	//save the number of time steps
	numberOfTimeSteps = numTimeSteps - 1;

	//if the rotation argument is true
	if(rotatingArg)
	{
		//set the data member rotating to true
		rotating = true;
		//save the rotation vector
		rotation = rotationArg;
		//save the rotation angle
		rotationAngle = rotationAngleArg;
	}
	//the rotation argument is false
	else
	{
		//set data member rotating to true
		rotating = false;
		//set the rotation vector to 0
		rotation = 0;
		//set the rotation angle to 0
		rotationAngle = 0;
	}
	//save the life time
	lifeTime = lifeTimeArg;
	
	//calculate the length of all the time steps
	for( int i = 0; i < numTimeSteps; i++)
	{
		timeStepToLifeTimeRatio += timeStepLengthArgArray[i];
	}
	//calculate the time step to life time ratio
	timeStepToLifeTimeRatio /= lifeTime;

	//save initial velocity
	velocity = velocityArgArray[0];
	//save initial gravity
	gravity = gravityArgArray[0];
	//save initial color
	color = colorArgArray[0];
	//save initial size
	size = sizeArgArray[0];

	//The purpose of this loop is to calculate the
	//velocity, gravity, color and size step values
	//for each time step, again we use numTimeSteps - 1
	//becuase the first time step is the inital Particle values
	for( int i = 0; i < numTimeSteps - 1; i++ )
	{
		//For the first time step add the first two time step
		//lengths so we don't ignore the first time step even
		//though we use it as the inital values.
		if( i == 0  )
		{
			//save the time step length we are going to work with
			currentTimeLength = ( timeStepLengthArgArray[i+1] + timeStepLengthArgArray[i] );
		}
		//this is not the first time step
		else
		{
			//save the time step length we are going to work with
			currentTimeLength = timeStepLengthArgArray[i + 1];
		}
		//divide the current time length we are working with
		//by the time step to lifetime ratio, so we can
		//reconsile differences between Particle life time
		//and time step lengths
		currentTimeLength /= timeStepToLifeTimeRatio;	

		//save the final time we are working with for later reference
		timeStepLengths[i] = currentTimeLength;

		//find the difference between adjecent time steps velocity
		velocityStep[i] = ( velocityArgArray[i+1] - velocityArgArray[i] );
		//find the difference between adjecent time steps gravity
		gravityStep[i] = ( gravityArgArray[i+1] - gravityArgArray[i] );
		//find the difference between adjecent time steps color
		colorStep[i] = ( colorArgArray[i+1] - colorArgArray[i] );
		//find the difference between adjecent time steps size
		sizeStep[i] = ( sizeArgArray[i+1] - sizeArgArray[i] );

		//divide the difference between the adjecent time step values
		//by the current time length so we get a value we can use
		//to interpolate between adjecent time steps
		velocityStep[i] /= currentTimeLength;
		//do the same for the gravity values
		gravityStep[i] /= currentTimeLength;
		//do the same for the color values
		colorStep[i] /= currentTimeLength;
		//do the same for the size values
		sizeStep[i] /= currentTimeLength;
		
	}

}

//-------------------------------------------------------------------//
// Function Prototype: bool Particle::Update(void) 
//
// Purpose: This methods adds the velocityStep, the gravityStep,
//			the colorStep and the sizeStep to the current velocity,
//			gravity, color and size, respectivly. The array element 
//			chosen from each step is determined by which Time Step
//			this Particle is currently on. The velocity and gravity
//			are then added and subtracted, respectivly from the Particles
//			position.
//
// Arguments: None
//
// Returns: bool - True if the Particle is still alive, false if 
//				the Particle is dead and it's lifetime over.
//
// Calls To: None
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
bool Particle::Update(void)
{
	//if this particle has exceeded it's lifetime
	//return false right away
	if(timeStepCounter >= lifeTime)
		return false;

	//store the time step we are on 
	int i = 0;
	//use to decide what time step we are in
	int timeLengthCounter = timeStepLengths[0];

	//keep incrementing i until we find which 
	//time step we are on
	while(timeStepCounter > timeLengthCounter)
	{
		i++;
		//add the next time steps length and check again
		timeLengthCounter += timeStepLengths[i];
	}
	//add the velocity step for this time step
	//to the current velocity
	velocity += &velocityStep[i];
	//add the gravity step for this time step
	//to the current gravity
	gravity += &gravityStep[i];
	//add the color step for this time step
	//to the current color	
	color += &colorStep[i];
	//add the size step for this time step
	//to the current size
	size += sizeStep[i];

	//add the current velocity to the position
	position += &velocity;
	//subtract the gravity from the position
	position -= &gravity;
	//increment the rotation angle 
	rotationAngle += .4; 
	//increment the time step counter
	timeStepCounter++;

	//return this particle is still alive
	return true;
}

//-------------------------------------------------------------------//
// Function Prototype: void Particle::Render(Vector3d Right, Vector3d Up)
//
// Purpose: This method is responsiable for actually, translating, 
//			rotationing (if necessary) and drawing the Particle
//			using it's current position, color and size.
//
// Arguments: Vector3d Right - The vector specifies the right
//					side of the view frustum.
//			  Vector3d Up - The vector specifies the up
//					side of the view frustum.
//
// Returns: void
//
// Calls To: glMatrixMode(), glPushMatrix(), glTranslatef()
//		     glRotatef(), glColor4fv(), glBegin(), glTexCoord2d()
//			 glVertex3fv(),	glTexCoord2d(), glVertex3fv(),
//			 glTexCoord2d(), glVertex3fv(), glTexCoord2d(), 
//			 glVertex3fv(), glEnd(), glPopMatrix()
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
void Particle::Render(Vector3d Right, Vector3d Up)
{		
	//use the argument to build two triangles
	//facing the camera and multiply by the size
	//of this particle
	
	//the bottom right cornor
	geometery[0] = (( Right - Up) * size);
	//the bottom left cornor
	geometery[1] = (( -Right - Up) * size);
	//the top right cornor
	geometery[2] = (( Right + Up) * size);
	//the top left cornor
	geometery[3] = (( -Right + Up) * size);

	//make sure that we are dealing with the model view matrix
	glMatrixMode(GL_MODELVIEW);
	//push a copy of the current matix on to the model view matrix stack
	glPushMatrix();

	//translate to this particles position
	glTranslatef(position.xyz[0],position.xyz[1],position.xyz[2]);
	//if this particle rotates...
	if(rotating)
	{
		//rotate the particle
        glRotatef( rotationAngle,rotation.xyz[0],rotation.xyz[1],rotation.xyz[2] );
	}
	//set the color of this particle
	glColor4fv(color.rgba);
	
	//begin specifing a triangle string
	glBegin(GL_TRIANGLE_STRIP);
		 
		//draw the first texute coordinate
		glTexCoord2d(1,0);
		//draw the first vertex
		glVertex3fv(geometery[0].xyz);
		//draw the second texture coordinate
		glTexCoord2d(0,0);
		//draw the second vertex
		glVertex3fv(geometery[1].xyz);
		//draw the third texture coordinate
		glTexCoord2d(1,1);
		//draw the third vertex - completing first triangle
		glVertex3fv(geometery[2].xyz);
		//draw the final texture coordinate
		glTexCoord2d(0,1);
		//the fourth vertex completes the second triangle
		glVertex3fv(geometery[3].xyz);
	
	//end draw a triangle strip
	glEnd();

	//remove the matrix we messed up
	glPopMatrix();
}
//-------------------------------------------------------------------//
// Function Prototype: char** Particle::ToString(void)
//
// Purpose: This method is converts all the data members to strings,
//			and then orginizes the strings into a two diamentional array.
//
// Arguments: void
//
// Returns: char** - A two diamension array of strings representing
//				the values of all the data members
//
// Calls To: Vector3d::ToString(), ColorRgba::ToString(), strncpy()
//			 strlen(), sprintf(), itoa()
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
char** Particle::ToString()
{
	char** dataString;
	dataString = new char*[9];
	char *buffer;
	char *conversionBuffer;
	int index = 0;
	buffer = new char[20000];
	conversionBuffer = new char[33]; 
	buffer[0] = '\0';
	conversionBuffer[0] = '\0';


	dataString[0] = new char[1024];
	for(int i = 0; i < numberOfTimeSteps; i++)
	{
		strncat(buffer,velocityStep[i].ToString( ),strlen(velocityStep[i].ToString( ) ) );
		strncat(buffer, "\n", 1);
		conversionBuffer[0] = '\0';
	}
	strcpy(dataString[0],buffer);
	buffer[0] = '\0';

	dataString[1] = new char[1024];
	for(int i = 0; i < numberOfTimeSteps; i++)
	{
		strncat(buffer,gravityStep[i].ToString( ),strlen(gravityStep[i].ToString( ) ) );
		strncat(buffer, "\n", 1);
		conversionBuffer[0] = '\0';
	}
	strcpy(dataString[1],buffer);
	buffer[0] = '\0';

	dataString[2] = new char[1024];
	for(int i = 0; i < numberOfTimeSteps; i++)
	{
		strncat(buffer,colorStep[i].ToString( ),strlen(colorStep[i].ToString( ) ) );
		strncat(buffer, "\n", 1);
		conversionBuffer[0] = '\0';
	}
	strcpy(dataString[2],buffer);
	buffer[0] = '\0';
	
	index = 0;
	for(int i = 0; i < numberOfTimeSteps; i++)
	{
		index += sprintf( conversionBuffer, " %f ",sizeStep[i]);
		strcat(buffer, conversionBuffer);
		strncat(buffer, "\n", 1);
		conversionBuffer[0] = '\0';
	}
	buffer[index] = '\0';
	dataString[3] = new char[strlen(buffer) + 2];
	strncpy(dataString[3], buffer, strlen(buffer));
	dataString[3][strlen(buffer)] = '\n';
	dataString[3][strlen(buffer) + 1] = '\0';
	buffer[0] = '\0';

	if(rotating)
	{
		dataString[4] = new char[strlen("True\n") + 1];
		dataString[4] = strncpy(dataString[4], "True\n" , strlen("True\n") );
		dataString[4][strlen("True\n")] = '\0';
	}
	else
	{
		dataString[4] = new char[strlen("False\n") + 1];
		dataString[4] = strncpy(dataString[4], "False\n" , strlen("False\n") );
		dataString[4][strlen("False\n")] = '\0';
	}
	dataString[5] = new char[strlen(rotation.ToString()) + 2];
	dataString[5] = strncpy(dataString[5], rotation.ToString(),strlen(rotation.ToString()));
	dataString[5][strlen(rotation.ToString())] = '\n';
	dataString[5][strlen(rotation.ToString()) + 1] = '\0';

	
	sprintf(conversionBuffer, " %f ",rotationAngle);
	dataString[6] = new char[strlen(conversionBuffer) + 2];
	dataString[6] = strncpy(dataString[6], conversionBuffer, strlen(conversionBuffer));
	dataString[6][strlen(conversionBuffer)] = '\n';
	dataString[6][strlen(conversionBuffer) + 1] = '\0';
	conversionBuffer[0] = '\0';
	
	dataString[7] = new char[strlen(itoa(lifeTime,conversionBuffer, 10)) + 2];
	dataString[7] = strncpy(dataString[7], conversionBuffer, strlen(conversionBuffer));
	dataString[7][strlen(itoa(lifeTime,conversionBuffer, 10) )] = '\n';
	dataString[7][strlen(itoa(lifeTime,conversionBuffer, 10) ) + 1] = '\0';
	conversionBuffer[0] = '\0';


	for(int i = 0; i < numberOfTimeSteps; i++)
	{	
		conversionBuffer = itoa(timeStepLengths[i],conversionBuffer,10);
		strncat(buffer,conversionBuffer, strlen(itoa(timeStepLengths[i],conversionBuffer,10)));
		strncat(buffer, "\n", 1);
		conversionBuffer[0] = '\0';
	}
	dataString[8] = new char[strlen(buffer) + 1];
	strncpy(dataString[8],buffer,strlen(buffer));
	dataString[8][strlen(buffer)] = '\0';
	buffer[0] = '\0';

	return dataString;
}
//-------------------------------------------------------------------//
// Function Prototype: Particle::~Particle(void)
//
// Purpose: This is the deconstructor, it deletes all dynamically 
//			allocated memory used by this Particle.
//
// Arguments: void
//
// Returns: (n/a)
//
// Calls To: none
//
// Author: James W. Cramer
//-------------------------------------------------------------------//	
Particle::~Particle()
{
	delete[] velocityStep;
	delete[] gravityStep;
	delete[] colorStep;
	delete[] sizeStep;
}


#endif