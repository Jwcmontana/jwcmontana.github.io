
================================================================
Model Name              : Terminator
installation directory  : c:\quake2\baseq2\players\Terminator
Author                  : Kurt 'Apocalypse" Cadogan
Email Address           : turbo911@datatone.com

Additional Credits to   :Gwot (Model Author)  
			 
================================================================
* Play Information *

New Sounds              : <NO>
CTF Skins               : <NO>
VWEP Support            : <YES>
I kept the blaster as the authors weapon ..In honor of his work.
 
* How to use this model *

place it into your  models dir and then load q2 normaly.
 

My thanks for Gwot for letting me work on the vwep .



 